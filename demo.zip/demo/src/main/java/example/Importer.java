package example;


import java.io.File;

public interface Importer {
    EBook importData(File data) ;
}


